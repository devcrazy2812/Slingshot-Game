# Decision Log

The agent appends a line here whenever it makes a choice that was not already in the docs. Format: `date | decision | reason`.

- Start | Vite + vanilla JS + Canvas 2D, zero runtime dependencies | Smallest attack surface, easiest to build with an AI agent
- Start | Bodies on analytic rails, ship is a test particle | Exact prediction, deterministic tests
- Start | Leapfrog integrator at fixed 1/120 s | Stable orbits
- Start | No backend, no analytics | Privacy and nothing to attack
