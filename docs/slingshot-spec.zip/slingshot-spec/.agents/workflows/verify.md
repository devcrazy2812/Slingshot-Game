---
description: Run all checks and report in plain English
---
1. Run `npm test` and show a one-line summary of passes and failures.
2. Run `npm run build` and report size of `dist/`.
3. Search `src/` for `eval(`, `new Function`, `innerHTML`, `document.write`, `fetch(`, `XMLHttpRequest`, `WebSocket`. Report any matches and fix or justify them.
4. Check `package.json`: only `vite` and `vitest` in devDependencies, exact versions, no runtime dependencies.
5. Confirm every number in `src/` that looks like a tunable lives in `src/config.js`.
6. Report in the format from AGENTS.md. Do not start a new milestone.
