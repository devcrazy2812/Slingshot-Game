---
description: Start the next unfinished milestone from docs/TASKS.md
---
1. Read `docs/TASKS.md` and `docs/DECISIONS.md`. Find the first milestone not yet committed (check `git log`).
2. Restate the milestone goal and its "Done when" line in two plain sentences.
3. List the files you will create or change before touching anything.
4. Implement only that milestone.
5. Run the `/verify` workflow.
6. Commit with a Conventional Commit message.
7. Report using the AGENTS.md format and wait for me to say "continue".
